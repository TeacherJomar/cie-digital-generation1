Project Name: project-2024
Advisers: Teacher Mike and Teacher Jomar
Story Created by: Teacher Jomar
Game Creators: CIE Digital Generation Club Members

Instructions to the Creators:
https://docs.google.com/document/d/1J9C8KqjGZpNuLYG3_1_QrFdZeO16PsnEYKaGb-X4fPc/edit?usp=sharing

For image generator:
https://deepai.org/machine-learning-model/text2img
